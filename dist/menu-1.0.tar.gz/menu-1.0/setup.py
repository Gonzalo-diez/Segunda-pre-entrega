from setuptools import setup

setup(
    name="menu",
    version="1.0",
    description="Paquete distribuido",
    author="Gonzalo Juan Diez",

    packages=["menu"]
)